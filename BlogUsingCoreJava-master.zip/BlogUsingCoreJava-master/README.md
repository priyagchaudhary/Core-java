# BlogUsingCoreJava
This is a typical Blog project using core JAVA and Sql.
It was my Fitst Java completed CRUD application.
Here i used Core java servlate and MySql data base.
